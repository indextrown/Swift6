//
//  LoginVC.swift
//  RxFlowTutorialTest
//
//  Created by Jeff Jeong on 2023/07/16.
//

import UIKit
import RxFlow
import RxSwift
import RxCocoa

class LoginVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func navigateToRegister(_ sender: Any) {
        print(#fileID, #function, #line, "- ")
    }
    
    @IBAction func navigateToPasswordFind(_ sender: Any) {
        print(#fileID, #function, #line, "- ")
    }
    
    @IBAction func navigateToAuthCheck(_ sender: Any) {
        print(#fileID, #function, #line, "- ")
    }
    
    @IBAction func navigateToEmailFind(_ sender: Any) {
        print(#fileID, #function, #line, "- ")
    }
    
    @IBAction func loginSuccess(_ sender: Any) {
        print(#fileID, #function, #line, "- ")
    }
}

