//
//  SplashVC.swift
//  RxFlowTutorialTest
//
//  Created by Jeff Jeong on 2023/07/16.
//

import UIKit
import RxFlow
import RxCocoa
import RxSwift
import RxRelay

class SplashVC: UIViewController {

    @IBOutlet weak var focusedSegmentControl: UISegmentedControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(#fileID, #function, #line, "- ")
    }
    
    
    @IBAction func alreadyLoggedInStep(_ sender: Any) {
        print(#fileID, #function, #line, "- ")
    }
    
    @IBAction func loginIsRequiredStep(_ sender: Any) {
        print(#fileID, #function, #line, "- ")
        
        let loginVC = LoginVC.instantiate("Auth")
        
        // MARK: - 스플래시 화면 -> 로그인 화면
        self.navigationController?.pushViewController(loginVC, animated: true)
    }
    
    
    @IBAction func navigateMainTab(_ sender: Any) {
        
        print(#fileID, #function, #line, "- ")
        
        let mainTabBar = UITabBarController()
        
        // MARK: - 홈, 즐겨찾기, 프로필 네비게이션 총 3개
        let homeVC = HomeVC.instantiate("Home")
        let homeNav = UINavigationController(rootViewController: homeVC)
        let homeTabBarItem = UITabBarItem(title: "홈", image: UIImage(systemName: "house"), tag: 0)
        homeNav.tabBarItem = homeTabBarItem
        
        let favoriteVC = FavoriteVC.instantiate("Favorite")
        let favoriteNav = UINavigationController(rootViewController: favoriteVC)
        let favoriteTabBarItem = UITabBarItem(title: "즐겨찾기", image: UIImage(systemName: "star.fill"), tag: 1)
        favoriteNav.tabBarItem = favoriteTabBarItem
        
        let profileVC = ProfileVC.instantiate("Profile")
        let profileNav = UINavigationController(rootViewController: profileVC)
        let profileTabBarItem = UITabBarItem(title: "프로필", image: UIImage(systemName: "person.fill"), tag: 2)
        profileNav.tabBarItem = profileTabBarItem
        
        mainTabBar.setViewControllers([homeNav, favoriteNav, profileNav], animated: true)
        // mainTabBar.tabBar.setItems([homeTabBarItem, favoriteTabBarItem, profileTabBarItem], animated: true)
        
        // 3가지가 만들어진거를 내가 가진 부모에 올라간다(내가 SplashVC이고 AppNavigation에 속해있다)
        self.navigationController?.pushViewController(mainTabBar, animated: true)
        
    }
    
}

